## produces wavefunction plots for output of dircap.f:
## 
## uses:     dc.out
##
## make multi-panel graph;
## set margins in order south, west, north, east
## oma is "outer margin" of entire figure
## mar is the margin of individual panels, which sets margin sizes in
##    order bottom, left, top, right
## mfcol=c(nrows, ncols) fills in the matrix by columns 
## tck sets tick mark lengths; negative value makes them point
##    outward
## las=1 shows tick mark labels in horizontal orientation
## mgp sets axis label locations relative to edge of inner plot window;
###   first value represents label locations [xlab, ylab], the second
###   the tick mark labels, the third the tick marks; default is c(3,1,0)

###################################
## USER INPUT FOR CHANGING x-RANGE:
   xlim <- c(0.1, 400)
###################################

# read data from file
mydatx <- read.table("dircap.out", header=FALSE, skip=26)

# write output to pdf file
pdf(file="plotDC2.pdf",width=5,height=8,onefile=F)

# define plot
par(mfcol=c(3,1), mar=c(3.5,6.5,1.0,3.0), oma=c(0.2,0.2,0.2,0.2), tck=0.05, 
    las=1, mgp=c(2.8,0.2,0))

# plot data
# cex controls symbol size
# pch is the symbol id
plot(mydatx[,1], mydatx[,2], main="", 
    cex.lab=1.1, cex.axis=1.0, cex.main=1.0, cex=1.3,
  	ylab=expression(paste("Bound state" )), xlab=expression(""), 
    pch=0, col=0,  xlim=xlim, log="x")       
lines(mydatx[,1], mydatx[,2], col="black", type="o", pch=".")

plot(mydatx[,1], mydatx[,3], main="", 
    cex.lab=1.1, cex.axis=1.0, cex.main=1.0, cex=1.3,
  	ylab=expression(paste("Unbound state" )), xlab=expression(""), 
    pch=0, col=0,  xlim=xlim, log="x")       
lines(mydatx[,1], mydatx[,3], col="black", type="o", pch=".")

plot(mydatx[,1], mydatx[,5], main="", 
    cex.lab=1.1, cex.axis=1.0, cex.main=1.0, cex=1.3,
  	ylab=expression(paste("Overlap" )), xlab=expression("Radial distance" ~ (fm)), 
    pch=0, col=0,  xlim=xlim, log="x")       
lines(mydatx[,1], mydatx[,5], col="black", type="o", pch=".")

## return output to the terminal
dev.off( )


